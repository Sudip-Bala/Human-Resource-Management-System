<?php
include 'db_connection.php';

$query = "SELECT id, name FROM employee";
$result = mysqli_query($conn, $query);

echo "<option value=''>Select Employee</option>";
while ($row = mysqli_fetch_assoc($result)) {
    echo "<option value='".$row['id']."'>".$row['name']."</option>";
}
?>
