<?php
include 'include/header.php';
include 'auth/auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Increment Form</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background-color: #f8f9fa;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-title {
            text-align: center;
            margin-bottom: 20px;
        }
        .employee-details {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2 class="form-title">Employee Increment Entry</h2>
            <form id="incrementForm" method="POST" action="save_increment.php">

                <!-- Employee Search -->
                <div class="form-group">
                    <label for="employee_id">Employee ID</label>
                    <input type="text" id="employee_id" name="employee_id" class="form-control" placeholder="Enter Employee ID" required>
                </div>
                <button type="button" class="btn btn-info btn-block" id="searchEmployeeBtn">Search Employee</button>
                <button type="button" class="btn btn-secondary btn-block" id="resetBtn">Reset</button><br>

                <!-- Employee Details -->
                <div class="employee-details" id="employeeDetails" style="display: none;">
                    <h5>Employee Details</h5>
                    <p><strong>Company:</strong> <span id="companyName"></span></p>
                    <p><strong>Department:</strong> <span id="departmentName"></span></p>
                    <p><strong>Designation:</strong> <span id="designationName"></span></p>
                    <p><strong>Name:</strong> <span id="employeeName"></span></p>
                    <p><strong>Salary:</strong> <span id="employeeSalary"></span></p>
                    <p><strong>Joining Date:</strong> <span id="joinDate"></span></p>
                </div>

                <!-- Increment Fields -->
                <div class="form-group">
                    <label for="increment_date">Increment Date</label>
                    <input type="date" id="increment_date" name="increment_date" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="increment_amount">Increment Amount</label>
                    <input type="number" id="increment_amount" name="increment_amount" class="form-control" step="0.01" required>
                </div>
                <button type="submit" class="btn btn-success btn-block">Save Increment</button>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            // Trigger search on Enter key press in employee_id field
            $('#employee_id').on('keydown', function(event) {
                if (event.key === "Enter") {
                    event.preventDefault();
                    searchEmployee();
                }
            });

            // Trigger search on button click
            $('#searchEmployeeBtn').click(function() {
                searchEmployee();
            });

            // Reset function
            $('#resetBtn').click(function() {
                resetForm();
            });

            // Search function
            function searchEmployee() {
                var employeeId = $('#employee_id').val();

                $.ajax({
                    url: 'search_employee.php',
                    method: 'POST',
                    data: { employee_id: employeeId },
                    success: function(response) {
                        var data = JSON.parse(response);

                        if (data.success) {
                            $('#companyName').text(data.company);
                            $('#departmentName').text(data.department);
                            $('#designationName').text(data.designation);
                            $('#employeeName').text(data.name);
                            $('#employeeSalary').text(data.salary);
                            $('#joinDate').text(data.join_date);
                            $('#employeeDetails').show();
                        } else {
                            alert('Employee not found');
                            $('#employeeDetails').hide();
                        }
                    }
                });
            }

            // Reset function to clear form fields
            function resetForm() {
                $('#employee_id').val('');
                $('#increment_date').val('');
                $('#increment_amount').val('');
                $('#companyName').text('');
                $('#departmentName').text('');
                $('#designationName').text('');
                $('#employeeName').text('');
                $('#employeeSalary').text('');
                $('#joinDate').text('');
                $('#employeeDetails').hide();
            }
        });
    </script>
</body>
</html>
