<?php
include 'db_connection.php';

$employee_id = $_POST['employee_id'];
$increment_date = $_POST['increment_date'];
$increment_amount = $_POST['increment_amount'];

$query = "INSERT INTO increment (employee_id, increment_date, increment_amount) VALUES ('$employee_id', '$increment_date', '$increment_amount')";
if (mysqli_query($conn, $query)) {
    echo "Increment saved successfully.";
    header("location: index.php");
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
