<?php
include 'db_connection.php';

$department_id = $_POST['department_id'];
$query = "SELECT id, name FROM designation WHERE department_id = $department_id";
$result = mysqli_query($conn, $query);

echo "<option value=''>Select Designation</option>";
while ($row = mysqli_fetch_assoc($result)) {
    echo "<option value='".$row['id']."'>".$row['name']."</option>";
}
?>
