<?php
include 'db_connection.php';

$company_id = $_POST['company_id'];
$query = "SELECT id, name FROM department WHERE company_id = $company_id";
$result = mysqli_query($conn, $query);

echo "<option value=''>Select Department</option>";
while ($row = mysqli_fetch_assoc($result)) {
    echo "<option value='".$row['id']."'>".$row['name']."</option>";
}
?>
