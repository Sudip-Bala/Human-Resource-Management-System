<?php
include 'db_connection.php';
include 'include/header.php';
include 'auth/auth.php';

$sql = " SELECT 
    e.id AS employee_id, 
    e.name AS employee_name, 
    c.name AS company_name, 
    d.name AS department_name, 
    des.name AS designation_name,
    e.join_date AS join_date, 
    e.salary AS current_salary, 
    COALESCE(SUM(i.increment_amount), 0) AS total_increment,
    (e.salary + COALESCE(SUM(i.increment_amount), 0)) AS total_salary
FROM 
    employee e
JOIN 
    designation des ON e.designation_id = des.id
JOIN 
    department d ON des.department_id = d.id
JOIN 
    company c ON d.company_id = c.id
LEFT JOIN 
    increment i ON e.id = i.employee_id
GROUP BY 
    e.id, c.id, d.id, des.id
ORDER BY 
    e.id
";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Data View</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .table-container {
            margin: 20px;
        }
    </style>
</head>
<body>
    <div class="container" align="center">
        <h2 class="text-center">Employee Data Overview</h2> <br>

        <table class="table table-bordered" align="center">
            <thead>
                <tr style="background-color: #FF8080 !important;">
                    <th>Emp ID</th>
                    <th>Name</th>
                    <th>Company</th>
                    <th>Department</th>
                    <th>Designation</th>
                    <th>Date of Joining</th>
                    <th>Current Salary</th>
                    <th>Total Increment</th>
                    <th>Total Salary</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['employee_id']; ?></td>
                            <td><?php echo $row['employee_name']; ?></td>
                            <td><?php echo $row['company_name']; ?></td>
                            <td><?php echo $row['department_name']; ?></td>
                            <td><?php echo $row['designation_name']; ?></td>
                            <td><?php echo $row['join_date']; ?></td>
                            <td><?php echo number_format($row['current_salary'], 2); ?></td>
                            <td><?php echo number_format($row['total_increment'], 2); ?></td>
                            <td><?php echo number_format($row['total_salary'], 2); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center">No records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
