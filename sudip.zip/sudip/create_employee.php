<?php
include 'include/header.php';
include 'auth/auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

        <style>
        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 30px;
            background-color: #0ABAB5;
            color: white;
            font-family: "Georgia", Times, serif;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-title {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>

</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2 class="form-title">Employee Entry From</h2>
            <form id="employeeForm" method="POST" action="save_employee.php">
                <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-4 col-form-label"><dt>Company :</dt></label>
                    <div class="col-sm-8">
                        <select id="company" name="company" class="form-control" required>
                            <option value="">Select Company</option>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-4 col-form-label"><dt>Department :</dt></label>
                    <div class="col-sm-8">
                        <select id="department" name="department" class="form-control" required>
                        <option value="">Select Department</option>
                    </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-4 col-form-label"><dt>Designation :</dt></label>
                    <div class="col-sm-8">
                        <select id="designation" name="designation" class="form-control" required>
                        <option value="">Select Designation</option>
                    </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-4 col-form-label"><dt>Employee Name :</dt></label>
                    <div class="col-sm-8">
                       <input type="text" id="name" name="name" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-4 col-form-label"><dt>Salary :</dt></label>
                    <div class="col-sm-8">
                       <input type="number" id="salary" name="salary" step="0.01" class="form-control" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputEmail3" class="col-sm-4 col-form-label"><dt>Joining Date :</dt></label>
                    <div class="col-sm-8">
                       <input type="date" id="join_date" name="join_date" class="form-control" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-success btn-block">CREATE</button>
                                
            </form> 
        </div> 
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>


    <script>
        $(document).ready(function() {
    // Load companies on page load
            $.ajax({
                url: 'get_companies.php',
                method: 'GET',
                success: function(data) {
                    $('#company').html(data);
                }
            });

    // Load departments based on selected company
            $('#company').change(function() {
                var companyId = $(this).val();
                $.ajax({
                    url: 'get_departments.php',
                    method: 'POST',
                    data: { company_id: companyId },
                    success: function(data) {
                        $('#department').html(data);
                    }
                });
            });

    // Load designations based on selected department
            $('#department').change(function() {
                var departmentId = $(this).val();
                $.ajax({
                    url: 'get_designations.php',
                    method: 'POST',
                    data: { department_id: departmentId },
                    success: function(data) {
                        $('#designation').html(data);
                    }
                });
            });
        });
    </script>
    <?php
    ?>

    <?php
    include 'db_connection.php';

    $sql = " SELECT 
    e.id AS employee_id, 
    e.name AS employee_name, 
    c.name AS company_name, 
    d.name AS department_name, 
    des.name AS designation_name, 
    e.salary AS current_salary,
    e.join_date AS join_date

    FROM 
    employee e
    JOIN 
    designation des ON e.designation_id = des.id
    JOIN 
    department d ON des.department_id = d.id
    JOIN 
    company c ON d.company_id = c.id
    GROUP BY 
    e.id, c.id, d.id, des.id
    ORDER BY 
    e.id
    ";

    $result = $conn->query($sql);
    ?>

    <body>
        <div class="container">
            <table class="table table-bordered">
                <thead>
                    <tr style="background-color: #FF8080 !important;">
                        <th>Employee ID</th>
                        <th>Name</th>
                        <th>Company</th>
                        <th>Department</th>
                        <th>Designation</th>
                        <th>Current Salary</th>
                        <th>Date Of Joining</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['employee_id']; ?></td>
                                <td><?php echo $row['employee_name']; ?></td>
                                <td><?php echo $row['company_name']; ?></td>
                                <td><?php echo $row['department_name']; ?></td>
                                <td><?php echo $row['designation_name']; ?></td>
                                <td><?php echo number_format($row['current_salary'], 2); ?></td>
                                <td><?php echo $row['join_date']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center">No records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </body>
    </html>

    <?php
    $conn->close();
    ?>
