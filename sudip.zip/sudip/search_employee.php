<?php
include 'db_connection.php';

$employee_id = $_POST['employee_id'];

// Fetch employee details with related data
$query = "SELECT e.name, e.salary, e.join_date, 
                 c.name AS company, d.name AS department, des.name AS designation
          FROM employee e
          JOIN designation des ON e.designation_id = des.id
          JOIN department d ON des.department_id = d.id
          JOIN company c ON d.company_id = c.id
          WHERE e.id = $employee_id";

$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    $employee = mysqli_fetch_assoc($result);
    echo json_encode([
        'success' => true,
        'company' => $employee['company'],
        'department' => $employee['department'],
        'designation' => $employee['designation'],
        'name' => $employee['name'],
        'salary' => $employee['salary'],
        'join_date' => $employee['join_date']
    ]);
} else {
    echo json_encode(['success' => false]);
}
?>
