<?php
include 'db_connection.php';

$name = $_POST['name'];
$designation_id = $_POST['designation'];
$salary = $_POST['salary'];
$join_date = $_POST['join_date'];

$query = "INSERT INTO employee (name, designation_id, salary, join_date) VALUES ('$name', '$designation_id', '$salary', '$join_date')";
if (mysqli_query($conn, $query)) {
    echo "Employee saved successfully.";
    header("location: create_employee.php");
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
